#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by Hao Luo at 2/11/20

"""__init__.py
:description : script
:param : 
:returns: 
:rtype: 
"""
def start():
    print("import successful")